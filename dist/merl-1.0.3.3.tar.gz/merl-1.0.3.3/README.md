# merl
An open-source useless python library. Developed using the code.org IDE, because why not.

If 'pip install "git+https://github.com/o9creeps/merl.git#egg=merl"' doesn't work, then gimmie some time i gotta figure THAT out.

## Functions
### send(pr) -- USE THIS
Sends 'pr' to Merl where 'pr' is a string.

### printanim(msg)
Prints 'msg' where 'msg' is a string. If 'msg' does not have spaces, then it all prints at once. Else, it prints word-by-word.

### replyPrint(prompt)
Where 'prompt' is a string. This makes Merl reply whatever, based on what you put in. Expect "I don't know." to show up more than once. With the exception of your system's time being between 9 AM and 4 PM, of course, because then you get a high traffic message more than half the time!
